"""
AUTHOR: @shreydan

this is the most bare-bones simplified code
I was able to make in this time.
ofcourse, this would've been way easier with trees
but this was made using 2D arrays.
Explanatory comments provided along each function
"""

# the below variables are global hence no parameters in functions
# to pass them again and again. 
entries = [] #stores all the inputs
entry_names_original = [] #original names list
entry_names = [] #stores names of the inputs without duplicates
points = [] #final list with all names and points added

def entry_names_simplifier():

    """
    this will remove duplicate names from a duplicate list
    to make adding the points easier
    """

    entry_names_original = [entries[i][0] for i in range(len(entries))]
    [entry_names.append(name) for name in entry_names_original if name not in entry_names]

def point_adder():

    """
    this will check the names present in the final list
    go through the original list
    create a new list points
    add the name and total points by iterating throughout
    """

    for name in entry_names:
        point = 0
        for i in range(len(entries)):
            if entries[i][0] == name:
                point += entries[i][1]
        points.append([name,point])


def max_finder():
    max_points = points[0]
    for i in range(len(points)):   
        if points[i][1] > max_points[1]:
            max_points = points[i]
    
    return max_points
    
        
def inputs():

    """
    this will take the inputs
    first you enter no. of entries
    follow the example
    different characters are converted to small alphabets
    to avoid duplicates with different alphabet case.
    """

    count = int(input('enter no. of entries '))
    print("e.g Hari 7 *hit enter*")
    for i in range(count):
        entry = input("-> ").split(' ')
        entry[0] = entry[0].lower() #al to small alphabets to avoid case mishap
        entry[1] = int(entry[1]) #converts points str -> int
        entries.append(entry) # adds to entry

inputs() # takes inputs
entry_names_simplifier() # does what it says
point_adder() # adds the points for each name
max_points = max_finder() # self-explanatory

print (entries)
print (points)
print (max_points[0], max_points[1])